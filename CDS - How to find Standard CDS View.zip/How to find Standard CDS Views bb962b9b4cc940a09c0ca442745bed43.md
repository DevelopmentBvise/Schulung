# How to find Standard CDS Views

1. Öffne Eclipse
2. Rechtsklick auf System Library → Configure Tree…
    
    ![Untitled](How%20to%20find%20Standard%20CDS%20Views%20bb962b9b4cc940a09c0ca442745bed43/Untitled.png)
    
3. Ändern der “Selected Tree Levels (preview)”.
    
    ![Untitled](How%20to%20find%20Standard%20CDS%20Views%20bb962b9b4cc940a09c0ca442745bed43/Untitled%201.png)
    
4. Im Project Explorer nun auf System Library → USE_IN_KEY_USER_APPS (oder USE_IN_CLOUD_DEVELOPMENT) → Core Data Services → Data Definition gehen.
    
    ![Untitled](How%20to%20find%20Standard%20CDS%20Views%20bb962b9b4cc940a09c0ca442745bed43/Untitled%202.png)
    
5. Jetzt anhand der Liste Standard CDS Views auswählen. Zum Beispiel auf I_PRODUCT und in der Data Preview ansehen.
6. 
    
    ![Untitled](How%20to%20find%20Standard%20CDS%20Views%20bb962b9b4cc940a09c0ca442745bed43/Untitled%203.png)
    
    ![Untitled](How%20to%20find%20Standard%20CDS%20Views%20bb962b9b4cc940a09c0ca442745bed43/Untitled%204.png)